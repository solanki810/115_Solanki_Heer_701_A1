console.log('Cleaning up temporary files...');
console.log('Cleanup completed!');
