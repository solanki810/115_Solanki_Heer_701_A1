console.log('Generating report...');
console.log('Report generated successfully!');
