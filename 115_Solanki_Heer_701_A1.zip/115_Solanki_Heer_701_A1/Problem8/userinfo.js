const os = require('os');
console.log(`User Info: ${os.userInfo().username}`);
