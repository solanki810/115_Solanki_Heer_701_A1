console.log('Test script executed successfully!');
