const calc = require('simple-calc-heer');

console.log(calc.add(5, 3));       
console.log(calc.subtract(5, 3)); 
